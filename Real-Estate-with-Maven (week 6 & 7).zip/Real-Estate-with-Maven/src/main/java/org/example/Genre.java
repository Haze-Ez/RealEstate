package org.example;

public enum Genre {FAMILYHOUSE, CONDOMINIUM, FARM,FLAT}
