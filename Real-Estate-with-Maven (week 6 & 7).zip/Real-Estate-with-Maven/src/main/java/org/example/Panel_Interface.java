package org.example;

public interface Panel_Interface {

    boolean hasSameAmmount(int value);

    int roomprice();
}
