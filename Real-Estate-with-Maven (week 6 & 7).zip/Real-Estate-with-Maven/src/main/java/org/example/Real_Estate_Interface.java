package org.example;

public interface Real_Estate_Interface {
    double makeDiscount(int percent);

    int getTotPrice();

    double avgsqmperroom();


    default String tostring(){
        return "";
    }
}
