package org.example;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Real_Estate_Agent {
    private static final Logger LOGGER = Logger.getLogger(Real_Estate_Agent.class.getName());
  public static TreeSet<Real_estate> stock = new TreeSet<>();

    public Real_Estate_Agent() {

      //   read("realestates.txt");


    }

    /**
     * addEstate - adds an estate to the stock
     * @param pieces
     */
    public void addEstate (String[]pieces){
        Genre newGenre = parse(pieces[5]);

        Real_estate estate1 = new Real_estate(pieces[1], Double.parseDouble(pieces[2]), Integer.parseInt(pieces[3]),
                Double.parseDouble(pieces[4]), newGenre);

        stock.add(estate1);
        LOGGER.log(Level.INFO,"Real-Estate added to the stock");
    }

    /**
     * addPanel - adds a Panel to the stock
     * @param pieces
     */
    public void addPanel (String[]pieces){
        Genre newGenre = parse(pieces[5]);
        boolean Ins;
        Ins = parse_bool(pieces[7]);

        Panel panel1 = new Panel(pieces[1], Double.parseDouble(pieces[2]), Integer.parseInt(pieces[3]),
                Double.parseDouble(pieces[4]), newGenre, Integer.parseInt(pieces[6]), Ins);

        stock.add(panel1);
        LOGGER.log(Level.INFO,"Panel added to the stock");
    }

    /**
     * parse_bool - checks for true or false
     *
     * @param insulated
     * @return true if yes and false if no
     */
    public boolean parse_bool (String insulated){
        LOGGER.log(Level.INFO, "Changing 'yes' to 'true'");
        return "yes".equalsIgnoreCase(insulated.trim());
    }

    /**
     * parse- parses the string value of genre to an actual genre value
     * @param genre
     * @return Genre type, Farm by default
     */
    public Genre parse (String genre){

        try {

            return Genre.valueOf(genre.toUpperCase());

        } catch (IllegalArgumentException e) {

            return Genre.FARM;
        }
    }

    /**
     * Check_valid checks if the string length is the expected value
     * @param pieces
     */
    public void Check_valid(String[] pieces){
        LOGGER.log(Level.INFO,"Checking if Property fits expected size 6 or 8 ");
        if (pieces.length != 6 && pieces.length != 8) {
            throw new IllegalArgumentException("Invalid input format: expected 6 or 8 parts but found " + pieces.length);
        }

        if (pieces.length == 6) {
            if (!"REALESTATE".equals(pieces[0])) {

                throw new IllegalArgumentException("Expected REALESTATE but found: " + pieces[0]);
            }
            addEstate(pieces);
        } else if (pieces.length == 8) {
            if (!"PANEL".equals(pieces[0])) {

                throw new IllegalArgumentException("Expected PANEL but found: " + pieces[0]);
            }
            addPanel(pieces);
        }
    }

    /**
     * read - reads contents in a text file and adds it to the stock
     * @param filename
     */
    public void read(String filename) {
        LOGGER.log(Level.INFO, "Reading file " + filename);
        File myObj = new File(filename);
        try (Scanner myReader = new Scanner(myObj)) {
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] pieces = data.split("#");

                Check_valid(pieces);
            }
        } catch (FileNotFoundException e) {
            LOGGER.log(Level.SEVERE, "Could not find: " + filename, e);
            System.err.println("File not found: " + filename);

            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            LOGGER.log(Level.SEVERE, "Error reading file: " + filename, e);
            System.err.println(e.getMessage());
        }
    }



}
