import org.example.Genre;
import org.example.Panel;
import org.example.Real_Estate_Agent;
import org.example.Real_estate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class Real_Estate_Agent_test {


    Real_Estate_Agent Mark;
    Real_estate Elite;
    Panel Sub_Elite;

    @BeforeEach
     void setUp() {
        Mark = new Real_Estate_Agent();
        Elite = new Real_estate("Budapest",2000000.0,480,10, Genre.FAMILYHOUSE);
        Sub_Elite = new Panel("Debrecen",1000000.0,240,5,Genre.CONDOMINIUM,2,true);
    }
    @Test
    public void test_parse() {
        String strToParse = "CONDOMINIUM";
        Genre expectedGenre = Genre.CONDOMINIUM;
        assertEquals(expectedGenre, Mark.parse(strToParse), "Parsing 'CONDOMINIUM' should return CONDOMINIUM");
    }

    @Test
    public void test_parseBool() {
        assertTrue(Mark.parse_bool("yes"), "Parsing 'yes' should return true");
        assertEquals(false, Mark.parse_bool("no"), "Parsing 'no' should return false");
    }


    @Test
    public void test_addEstate(){
        int initialSize = Mark.stock.size();
        String demo = "REALESTATE#Budapest#2000000#480#10#FAMILYHOUSE";
        String[] parts = demo.split("#");
        Mark.addEstate(parts);
        int finalSize = Mark.stock.size();

        assertTrue(finalSize > initialSize, "Stock size should increase after adding a new estate");

    }

    @Test
    public void test_addPanel(){
        int initialSize = Mark.stock.size();
        String demo = "PANEL#Debrecen#1000000#240#5#CONDOMINIUM#2#true";
        String[] parts2 = demo.split("#");
        Mark.addEstate(parts2);
        int finalSize = Mark.stock.size();

        assertTrue(finalSize > initialSize, "Stock size should increase after adding a new panel");

    }

    @Test
    public void  test_read(){
        String testFileContent = """
                REALESTATE#Budapest#2000000#480#10#FAMILYHOUSE
                PANEL#Debrecen#1000000#240#5#CONDOMINIUM#2#yes
                """;
        String testFileName = "test_realestates.txt";
        try (java.io.PrintWriter writer = new java.io.PrintWriter(testFileName)) {//create a test txt file
            writer.print(testFileContent);//write content to the test file
        } catch (java.io.IOException e) {
            throw new RuntimeException("Could not create test file", e);
        }
        Mark.read(testFileName);
        assertEquals(2,Mark.stock.size());//content read and added to stock
    }



}

