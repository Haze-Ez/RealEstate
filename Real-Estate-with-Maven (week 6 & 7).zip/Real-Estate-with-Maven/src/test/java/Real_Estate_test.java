import org.example.Genre;
import org.example.Panel;
import org.example.Real_Estate_Agent;
import org.example.Real_estate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class Real_Estate_test {

    Real_estate underTest;
    Panel test2;

    /**
     * BeforeEach setup
     */
    @BeforeEach
    void setup() {
        underTest = new Real_estate("Debrecen",
                500000.0, 40, 2,
                Genre.CONDOMINIUM);
        test2 = new Panel("Debrecen", 500000.0, 40, 2, Genre.CONDOMINIUM,4,false);
    }

    /**
     * Test make discount
     */
    @Test
    void testMakeDiscountShouldReturnCorrectValue() {
        underTest.makeDiscount(10);
        double actual = underTest.getPrice();
        double expected = 450000.0;
        assertEquals(expected, actual, "makeDiscount miscalculates something");
    }

    @Test
    void testMakeDiscountwith_0(){
        underTest.makeDiscount(0);
        double actual = underTest.getPrice();
        double expected = 500000.0;

        assertEquals(expected, actual, "makeDiscount miscalculates something");
    }


    /**
     * Test compareto with lower price but same property
     */
    @Test
    void testCompareto_Lower_Price() {
        Real_estate other = new Real_estate("Debrecen", 43000.0, 20, 2, Genre.CONDOMINIUM);
        assertTrue(other.compareTo(underTest) < 0);

    }
    /**
     * Test compareto with higher price but same property
     */

    @Test
    void testCompareto_Higher_Price() {
        Real_estate other = new Real_estate("Debrecen", 43000.0, 20, 2, Genre.CONDOMINIUM);
        assertTrue(underTest.compareTo(other) > 0);

    }
    /**
     * Test compareto with higher sqm but same property
     */

    @Test
    void testCompareto_sameprice_diff_high_sqm() {
        Real_estate other = new Real_estate("Debrecen", 500000.0, 20, 4, Genre.CONDOMINIUM);
        assertTrue(underTest.compareTo(other) > 0);

    }
    /**
     * Test compareto with lower sqm but same property
     */

    @Test
    void testCompareto_sameprice_diff_low_sqm() {
        Real_estate other = new Real_estate("Debrecen", 500000.0, 80, 4, Genre.CONDOMINIUM);
        assertTrue(underTest.compareTo(other) < 0);

    }

    /**
     * Test compareto with higher number of rooms but same property
     */
    @Test
    void testCompareto_samesqm_diff_high_numofrooms() {
        Real_estate other = new Real_estate("Debrecen", 500000.0, 40, 4, Genre.CONDOMINIUM);
        assertTrue(underTest.compareTo(other) < 0);

    }

    /**
     * Test compareto with lower number of rooms but same property
     */
    @Test
    void testCompareto_samesqm_diff_low_numofrooms() {
        Real_estate other = new Real_estate("Debrecen", 500000.0, 40, 1, Genre.CONDOMINIUM);
        assertTrue(underTest.compareTo(other) > 0);

    }

    /**
     * Test compareto same property
     */
    @Test
    void testCompareto_same_property() {
        Real_estate other = new Real_estate("Debrecen", 500000.0, 40, 2, Genre.CONDOMINIUM);
        assertTrue(underTest.compareTo(other) == 0,"Same propoerty miscalculates something");

    }

    /**
     * test Total price of properties in Bud
     */
    @Test
    void testTotal_Price_Bud() {
        Real_estate other = new Real_estate("Budapest", 600000.0, 20, 4, Genre.FAMILYHOUSE);
        assertEquals(other.getTotPrice(),3120000);

    }

    /**
     * test Total price of properties in Deb
     */
    @Test
    void testTotal_Price_Deb() {
        assertEquals(underTest.getTotPrice(),1200000);

    }

    /**
     * test Total price of properties in Nye
     */
    @Test
    void testTotal_Price_Nye() {
        Real_estate other = new Real_estate("Nyiregyhaza", 140000.0, 5, 3, Genre.FAMILYHOUSE);
        assertEquals( other.getTotPrice(),483000);
    }

    /**
     * test avg sqm/room method
     */
    @Test
    void testavg_sqm_room() {
        assertEquals( underTest.avgsqmperroom(),20.0);
    }

    /**
     * test tostring method
     */
    @Test
    void test_tostring() {
        String actual = underTest.toString();
        String expected = underTest.toString();
        assertEquals(expected, actual);
    }

    /**
     * test has same amount mehtod
     */
    @Test
    void test_has_same_amount(){
        assertTrue(test2.hasSameAmmount(1200000),"Not same amount as total-price");
    }

    /**
     * test roomprice method
     */
    @Test
    void test_room_price(){
        int actual = 250000;
        int expected = test2.roomprice();
        assertEquals(expected,actual,"Room price miscalculates something");
    }


}
